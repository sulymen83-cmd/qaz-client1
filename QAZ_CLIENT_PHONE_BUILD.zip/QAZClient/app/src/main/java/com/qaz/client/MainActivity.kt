package com.qaz.client

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
            setBackgroundColor(0xFF101827.toInt())
        }
        val title = TextView(this).apply {
            text = "QAZ CLIENT"
            textSize = 28f
            setTextColor(0xFF55B8FF.toInt())
        }
        val subtitle = TextView(this).apply {
            text = "Minecraft Bedrock companion overlay"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 8, 0, 24)
        }
        val permission = Button(this).apply {
            text = "Разрешить отображение поверх окон"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivity(intent)
                } else startOverlay()
            }
        }
        val start = Button(this).apply {
            text = "Запустить QAZ MENU"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else startOverlay()
            }
        }
        layout.addView(title); layout.addView(subtitle); layout.addView(permission); layout.addView(start)
        setContentView(layout)
    }

    private fun startOverlay() {
        startService(Intent(this, OverlayService::class.java))
        finish()
    }
}
