package com.qaz.client

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun params(width: Int, height: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            width, height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 180 }

    private fun showBubble() {
        val b = TextView(this).apply {
            text = "Q"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = shape(0xFF087AC4.toInt(), 100f)
            setOnClickListener { togglePanel() }
            setOnTouchListener(DragTouchListener())
        }
        bubble = b
        wm.addView(b, params(58, 58))
    }

    private fun togglePanel() {
        if (panel != null) {
            wm.removeView(panel); panel = null
            return
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
            background = shape(0xEE101827.toInt(), 18f)
        }
        val heading = TextView(this).apply {
            text = "QAZ MENU  •  BETA"
            textSize = 18f
            setTextColor(0xFF55B8FF.toInt())
            setPadding(0, 0, 0, 12)
        }
        box.addView(heading)
        listOf("Fly (демо)", "Speed (демо)", "ESP (демо)", "X-Ray (демо)", "Sprint (демо)").forEach { name ->
            var enabled = false
            val button = Button(this).apply {
                text = "$name: OFF"
                setOnClickListener {
                    enabled = !enabled
                    text = "$name: ${if (enabled) "ON" else "OFF"}"
                }
            }
            box.addView(button)
        }
        val close = Button(this).apply {
            text = "Закрыть меню"
            setOnClickListener { togglePanel() }
        }
        box.addView(close)
        panel = box
        wm.addView(box, params(270, WindowManager.LayoutParams.WRAP_CONTENT).apply { x = 92; y = 180 })
    }

    private fun shape(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius
    }

    private inner class DragTouchListener : View.OnTouchListener {
        private var startX = 0; private var startY = 0
        private var touchX = 0f; private var touchY = 0f
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            val lp = v.layoutParams as WindowManager.LayoutParams
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = event.rawX; touchY = event.rawY
                    return false
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (event.rawX - touchX).toInt()
                    lp.y = startY + (event.rawY - touchY).toInt()
                    wm.updateViewLayout(v, lp)
                    return true
                }
            }
            return false
        }
    }

    override fun onDestroy() {
        bubble?.let { wm.removeView(it) }
        panel?.let { wm.removeView(it) }
        super.onDestroy()
    }
}
